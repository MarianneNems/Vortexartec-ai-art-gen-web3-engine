<?php
/**
 * VORTEX AI Engine - Simple Status Test
 * 
 * Basic diagnostic that should work even with strict server settings
 */

// Simple WordPress bootstrap
if (file_exists(__DIR__ . '/../../../wp-load.php')) {
    require_once __DIR__ . '/../../../wp-load.php';
} else {
    echo "WordPress not found\n";
    exit;
}

echo "<h2>VORTEX AI Engine - Basic Status Check</h2>\n";
echo "<p>Time: " . date('Y-m-d H:i:s') . "</p>\n";

// 1. Basic WordPress Check
echo "<h3>1. WordPress Status</h3>\n";
echo "<p>WordPress Version: " . get_bloginfo('version') . "</p>\n";
echo "<p>PHP Version: " . PHP_VERSION . "</p>\n";
echo "<p>Memory Limit: " . ini_get('memory_limit') . "</p>\n";

// 2. Plugin Status
echo "<h3>2. Plugin Status</h3>\n";
$plugins = get_option('active_plugins');
echo "<p>Active Plugins: " . count($plugins) . "</p>\n";

$vortex_active = in_array('vortex-ai-engine/vortex-ai-engine.php', $plugins);
echo "<p>Vortex AI Engine: " . ($vortex_active ? 'ACTIVE' : 'NOT ACTIVE') . "</p>\n";

$woocommerce_active = in_array('woocommerce/woocommerce.php', $plugins);
echo "<p>WooCommerce: " . ($woocommerce_active ? 'ACTIVE' : 'NOT ACTIVE') . "</p>\n";

$wc_blocks_active = in_array('woocommerce-blocks/woocommerce-blocks.php', $plugins);
echo "<p>WooCommerce Blocks: " . ($wc_blocks_active ? 'ACTIVE' : 'NOT ACTIVE') . "</p>\n";

// 3. File Check
echo "<h3>3. File Check</h3>\n";
$plugin_file = WP_PLUGIN_DIR . '/vortex-ai-engine/vortex-ai-engine.php';
echo "<p>Main Plugin File: " . (file_exists($plugin_file) ? 'EXISTS' : 'MISSING') . "</p>\n";

$includes_dir = WP_PLUGIN_DIR . '/vortex-ai-engine/includes';
echo "<p>Includes Directory: " . (is_dir($includes_dir) ? 'EXISTS' : 'MISSING') . "</p>\n";

// 4. Debug Settings
echo "<h3>4. Debug Settings</h3>\n";
echo "<p>WP_DEBUG: " . (defined('WP_DEBUG') && WP_DEBUG ? 'ENABLED' : 'DISABLED') . "</p>\n";
echo "<p>WP_DEBUG_LOG: " . (defined('WP_DEBUG_LOG') && WP_DEBUG_LOG ? 'ENABLED' : 'DISABLED') . "</p>\n";

// 5. Error Log Check
echo "<h3>5. Recent Errors</h3>\n";
$log_file = WP_CONTENT_DIR . '/debug.log';
if (file_exists($log_file)) {
    $log_content = file_get_contents($log_file);
    $lines = explode("\n", $log_content);
    $recent = array_slice($lines, -5);
    echo "<p>Last 5 log entries:</p>\n";
    echo "<pre style='background:#f5f5f5;padding:10px;'>\n";
    foreach ($recent as $line) {
        if (trim($line)) {
            echo htmlspecialchars($line) . "\n";
        }
    }
    echo "</pre>\n";
} else {
    echo "<p>No debug.log file found</p>\n";
}

// 6. Activation Test
echo "<h3>6. Activation Test</h3>\n";
if (!$vortex_active) {
    echo "<p><a href='" . admin_url('plugins.php?action=activate&plugin=vortex-ai-engine/vortex-ai-engine.php&_wpnonce=' . wp_create_nonce('activate-plugin_vortex-ai-engine/vortex-ai-engine.php')) . "'>Click here to try activating Vortex AI Engine</a></p>\n";
} else {
    echo "<p>Plugin is already active!</p>\n";
}

echo "<hr>\n";
echo "<p><strong>If you see this page, the basic WordPress connection is working.</strong></p>\n";
echo "<p>Please copy and paste this entire output to share with support.</p>\n";
?> 