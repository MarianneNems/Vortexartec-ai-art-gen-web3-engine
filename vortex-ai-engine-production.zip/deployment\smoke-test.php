<?php
/**
 * Vortex AI Engine - Smoke Test Script
 * 
 * Tests all shortcodes, REST endpoints, and plugin functionality
 * Run this after plugin activation to verify everything works
 * 
 * @package VortexAIEngine
 * @since 2.2.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    // Load WordPress if not already loaded
    if (!file_exists('../../../wp-config.php')) {
        die('❌ WordPress not found. Please run this script from wp-content/plugins/vortex-ai-engine/deployment/');
    }
    require_once '../../../wp-config.php';
}

class Vortex_Smoke_Test {
    
    private $test_results = [];
    private $site_url;
    
    public function __construct() {
        $this->site_url = get_site_url();
    }
    
    /**
     * Run all smoke tests
     */
    public function run_smoke_tests() {
        echo "🚀 VORTEX AI ENGINE - Smoke Test Suite\n";
        echo "=====================================\n\n";
        
        $this->test_plugin_activation();
        $this->test_shortcodes();
        $this->test_rest_endpoints();
        $this->test_agreement_modal();
        $this->test_ai_agents();
        $this->test_admin_dashboard();
        $this->test_database_operations();
        $this->test_aws_integration();
        
        $this->display_results();
    }
    
    /**
     * Test plugin activation
     */
    private function test_plugin_activation() {
        echo "🔌 1. Testing plugin activation...\n";
        
        // Check if plugin is active
        if (is_plugin_active('vortex-ai-engine/vortex-ai-engine.php')) {
            $this->add_result('Plugin Activation', 'PASS', 'Plugin is active');
        } else {
            $this->add_result('Plugin Activation', 'FAIL', 'Plugin is not active');
        }
        
        // Check if main class exists
        if (class_exists('Vortex_AI_Engine')) {
            $this->add_result('Main Class', 'PASS', 'Vortex_AI_Engine class loaded');
        } else {
            $this->add_result('Main Class', 'FAIL', 'Vortex_AI_Engine class not found');
        }
        
        // Check if agreement policy is loaded
        if (class_exists('Vortex_Agreement_Policy')) {
            $this->add_result('Agreement Policy', 'PASS', 'Agreement policy loaded');
        } else {
            $this->add_result('Agreement Policy', 'FAIL', 'Agreement policy not found');
        }
        
        echo "   Completed plugin activation tests\n\n";
    }
    
    /**
     * Test shortcodes
     */
    private function test_shortcodes() {
        echo "📝 2. Testing shortcodes...\n";
        
        $shortcodes = [
            'vortex_swap' => '[vortex_swap]',
            'vortex_wallet' => '[vortex_wallet]',
            'vortex_metric' => '[vortex_metric type="ranking"]',
            'vortex_chat' => '[vortex_chat]',
            'vortex_feedback' => '[vortex_feedback]',
            'huraii_generate' => '[huraii_generate prompt="test"]',
            'huraii_voice' => '[huraii_voice text="test"]'
        ];
        
        foreach ($shortcodes as $name => $shortcode) {
            $output = do_shortcode($shortcode);
            
            if (!empty($output) && $output !== $shortcode) {
                $this->add_result("Shortcode: {$name}", 'PASS', 'Shortcode rendered successfully');
            } else {
                $this->add_result("Shortcode: {$name}", 'FAIL', 'Shortcode failed to render');
            }
        }
        
        echo "   Completed shortcode tests\n\n";
    }
    
    /**
     * Test REST endpoints
     */
    private function test_rest_endpoints() {
        echo "🌐 3. Testing REST endpoints...\n";
        
        $endpoints = [
            'feedback' => '/wp-json/vortex/v1/feedback',
            'generate' => '/wp-json/vortex/v1/generate',
            'wallet' => '/wp-json/vortex/v1/wallet',
            'swap' => '/wp-json/vortex/v1/swap',
            'metrics' => '/wp-json/vortex/v1/metrics'
        ];
        
        foreach ($endpoints as $name => $endpoint) {
            $url = $this->site_url . $endpoint;
            $response = wp_remote_get($url);
            
            if (!is_wp_error($response)) {
                $status_code = wp_remote_retrieve_response_code($response);
                if ($status_code === 200 || $status_code === 401) { // 401 is expected for unauthenticated requests
                    $this->add_result("REST: {$name}", 'PASS', "Endpoint responded with status {$status_code}");
                } else {
                    $this->add_result("REST: {$name}", 'FAIL', "Endpoint returned status {$status_code}");
                }
            } else {
                $this->add_result("REST: {$name}", 'FAIL', 'Endpoint request failed: ' . $response->get_error_message());
            }
        }
        
        echo "   Completed REST endpoint tests\n\n";
    }
    
    /**
     * Test agreement modal
     */
    private function test_agreement_modal() {
        echo "📜 4. Testing agreement modal...\n";
        
        // Test agreement policy functionality
        if (class_exists('Vortex_Agreement_Policy')) {
            $agreement = Vortex_Agreement_Policy::get_instance();
            
            // Test agreement check
            $has_agreed = $agreement->has_user_agreed();
            if (is_bool($has_agreed)) {
                $this->add_result('Agreement Check', 'PASS', 'Agreement check method works');
            } else {
                $this->add_result('Agreement Check', 'FAIL', 'Agreement check method failed');
            }
            
            // Test agreement assets
            $js_file = plugin_dir_url(__FILE__) . '../assets/js/agreement.js';
            $css_file = plugin_dir_url(__FILE__) . '../assets/css/agreement.css';
            
            $js_response = wp_remote_get($js_file);
            $css_response = wp_remote_get($css_file);
            
            if (!is_wp_error($js_response) && wp_remote_retrieve_response_code($js_response) === 200) {
                $this->add_result('Agreement JS', 'PASS', 'JavaScript file accessible');
            } else {
                $this->add_result('Agreement JS', 'FAIL', 'JavaScript file not accessible');
            }
            
            if (!is_wp_error($css_response) && wp_remote_retrieve_response_code($css_response) === 200) {
                $this->add_result('Agreement CSS', 'PASS', 'CSS file accessible');
            } else {
                $this->add_result('Agreement CSS', 'FAIL', 'CSS file not accessible');
            }
        } else {
            $this->add_result('Agreement Policy', 'FAIL', 'Agreement policy class not found');
        }
        
        echo "   Completed agreement modal tests\n\n";
    }
    
    /**
     * Test AI agents
     */
    private function test_ai_agents() {
        echo "🤖 5. Testing AI agents...\n";
        
        $agents = [
            'Archer Orchestrator' => 'VORTEX_ARCHER_Orchestrator',
            'Huraii Agent' => 'Vortex_Huraii_Agent',
            'Cloe Agent' => 'Vortex_Cloe_Agent',
            'Horace Agent' => 'Vortex_Horace_Agent',
            'Thorius Agent' => 'Vortex_Thorius_Agent'
        ];
        
        foreach ($agents as $name => $class) {
            if (class_exists($class)) {
                $this->add_result("AI Agent: {$name}", 'PASS', "Agent class loaded");
                
                // Test get_instance method if it exists
                if (method_exists($class, 'get_instance')) {
                    try {
                        $instance = call_user_func([$class, 'get_instance']);
                        if ($instance) {
                            $this->add_result("AI Agent: {$name} Instance", 'PASS', 'Agent instance created');
                        } else {
                            $this->add_result("AI Agent: {$name} Instance", 'FAIL', 'Failed to create agent instance');
                        }
                    } catch (Exception $e) {
                        $this->add_result("AI Agent: {$name} Instance", 'FAIL', 'Exception: ' . $e->getMessage());
                    }
                }
            } else {
                $this->add_result("AI Agent: {$name}", 'FAIL', 'Agent class not found');
            }
        }
        
        echo "   Completed AI agent tests\n\n";
    }
    
    /**
     * Test admin dashboard
     */
    private function test_admin_dashboard() {
        echo "⚙️ 6. Testing admin dashboard...\n";
        
        // Check if admin menu is registered
        global $menu;
        $vortex_menu_found = false;
        
        foreach ($menu as $item) {
            if (isset($item[0]) && strpos($item[0], 'Vortex') !== false) {
                $vortex_menu_found = true;
                break;
            }
        }
        
        if ($vortex_menu_found) {
            $this->add_result('Admin Menu', 'PASS', 'Vortex admin menu registered');
        } else {
            $this->add_result('Admin Menu', 'FAIL', 'Vortex admin menu not found');
        }
        
        // Test admin page URLs
        $admin_pages = [
            'Vortex AI Engine' => admin_url('admin.php?page=vortex-ai-engine'),
            'Artist Journey' => admin_url('admin.php?page=vortex-artist-journey'),
            'Activity Monitor' => admin_url('admin.php?page=vortex-activity-monitor'),
            'Agreements' => admin_url('admin.php?page=vortex-agreements')
        ];
        
        foreach ($admin_pages as $name => $url) {
            $response = wp_remote_get($url);
            
            if (!is_wp_error($response)) {
                $status_code = wp_remote_retrieve_response_code($response);
                if ($status_code === 200) {
                    $this->add_result("Admin Page: {$name}", 'PASS', 'Admin page accessible');
                } else {
                    $this->add_result("Admin Page: {$name}", 'FAIL', "Admin page returned status {$status_code}");
                }
            } else {
                $this->add_result("Admin Page: {$name}", 'FAIL', 'Admin page request failed');
            }
        }
        
        echo "   Completed admin dashboard tests\n\n";
    }
    
    /**
     * Test database operations
     */
    private function test_database_operations() {
        echo "🗄️ 7. Testing database operations...\n";
        
        global $wpdb;
        
        // Test activity logging
        if (class_exists('Vortex_Activity_Logger')) {
            try {
                $logger = Vortex_Activity_Logger::get_instance();
                $result = $logger->log_activity('smoke_test', 'Testing activity logging', ['test' => true]);
                
                if ($result) {
                    $this->add_result('Activity Logging', 'PASS', 'Activity logged successfully');
                } else {
                    $this->add_result('Activity Logging', 'FAIL', 'Failed to log activity');
                }
            } catch (Exception $e) {
                $this->add_result('Activity Logging', 'FAIL', 'Exception: ' . $e->getMessage());
            }
        } else {
            $this->add_result('Activity Logging', 'FAIL', 'Activity logger class not found');
        }
        
        // Test user metadata
        $test_user_id = get_current_user_id();
        if ($test_user_id) {
            $test_meta = 'vortex_smoke_test_' . time();
            $meta_result = update_user_meta($test_user_id, $test_meta, 'test_value');
            
            if ($meta_result) {
                $this->add_result('User Metadata', 'PASS', 'User metadata operations work');
                delete_user_meta($test_user_id, $test_meta); // Clean up
            } else {
                $this->add_result('User Metadata', 'FAIL', 'User metadata operations failed');
            }
        } else {
            $this->add_result('User Metadata', 'SKIP', 'No logged-in user for testing');
        }
        
        echo "   Completed database operation tests\n\n";
    }
    
    /**
     * Test AWS integration
     */
    private function test_aws_integration() {
        echo "☁️ 8. Testing AWS integration...\n";
        
        // Check AWS constants
        $aws_configured = defined('AWS_ACCESS_KEY_ID') && defined('AWS_SECRET_ACCESS_KEY') && defined('AWS_DEFAULT_REGION');
        
        if ($aws_configured) {
            $this->add_result('AWS Configuration', 'PASS', 'AWS credentials configured');
            
            // Test AWS SDK if available
            if (class_exists('Aws\Sqs\SqsClient')) {
                try {
                    $sqs = new Aws\Sqs\SqsClient([
                        'version' => 'latest',
                        'region'  => AWS_DEFAULT_REGION,
                        'credentials' => [
                            'key'    => AWS_ACCESS_KEY_ID,
                            'secret' => AWS_SECRET_ACCESS_KEY,
                        ]
                    ]);
                    
                    // Try to list queues
                    $result = $sqs->listQueues();
                    $this->add_result('AWS SQS', 'PASS', 'SQS connection successful');
                } catch (Exception $e) {
                    $this->add_result('AWS SQS', 'FAIL', 'SQS connection failed: ' . $e->getMessage());
                }
            } else {
                $this->add_result('AWS SQS', 'SKIP', 'AWS SDK not available');
            }
        } else {
            $this->add_result('AWS Configuration', 'SKIP', 'AWS not configured');
        }
        
        echo "   Completed AWS integration tests\n\n";
    }
    
    /**
     * Add test result
     */
    private function add_result($test, $status, $message) {
        $this->test_results[] = [
            'test' => $test,
            'status' => $status,
            'message' => $message,
            'timestamp' => current_time('mysql')
        ];
    }
    
    /**
     * Display test results
     */
    private function display_results() {
        echo "📊 SMOKE TEST RESULTS\n";
        echo "====================\n\n";
        
        $passed = 0;
        $failed = 0;
        $skipped = 0;
        
        foreach ($this->test_results as $result) {
            $status_icon = $result['status'] === 'PASS' ? '✅' : ($result['status'] === 'FAIL' ? '❌' : '⏭️');
            echo "{$status_icon} {$result['test']}: {$result['message']}\n";
            
            if ($result['status'] === 'PASS') $passed++;
            elseif ($result['status'] === 'FAIL') $failed++;
            else $skipped++;
        }
        
        echo "\n📈 SUMMARY:\n";
        echo "   Total Tests: " . count($this->test_results) . "\n";
        echo "   Passed: {$passed}\n";
        echo "   Failed: {$failed}\n";
        echo "   Skipped: {$skipped}\n\n";
        
        if ($failed === 0) {
            echo "🎉 Smoke tests PASSED!\n";
            echo "   Plugin is ready for production deployment.\n";
        } else {
            echo "🚨 Smoke tests FAILED!\n";
            echo "   Please fix the failing tests before deployment.\n";
        }
        
        echo "\n";
    }
}

// Run smoke tests if script is executed directly
if (basename(__FILE__) === basename($_SERVER['SCRIPT_NAME'])) {
    $smoke_test = new Vortex_Smoke_Test();
    $smoke_test->run_smoke_tests();
} 